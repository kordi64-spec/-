package com.example.facegaze

import org.junit.Assert.assertEquals
import org.junit.Test

class GazeEstimatorTest {
    @Test fun center() = assertEquals(GazeDirection.CENTER, GazeEstimator.estimateFromRatios(0.50f, 0.50f).direction)
    @Test fun left() = assertEquals(GazeDirection.LEFT, GazeEstimator.estimateFromRatios(0.30f, 0.50f).direction)
    @Test fun right() = assertEquals(GazeDirection.RIGHT, GazeEstimator.estimateFromRatios(0.72f, 0.50f).direction)
    @Test fun up() = assertEquals(GazeDirection.UP, GazeEstimator.estimateFromRatios(0.50f, 0.28f).direction)
    @Test fun down() = assertEquals(GazeDirection.DOWN, GazeEstimator.estimateFromRatios(0.50f, 0.76f).direction)
}
