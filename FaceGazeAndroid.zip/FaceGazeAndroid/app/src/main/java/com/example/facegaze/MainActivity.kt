package com.example.facegaze

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.AspectRatio
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.facegaze.databinding.ActivityMainBinding
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity(), FaceLandmarkerHelper.Listener {
    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var faceLandmarker: FaceLandmarkerHelper
    private val gazeEstimator = GazeEstimator()

    @Volatile private var gazeTracking = false
    private var snapshotMode = false

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else binding.statusText.text = "اجازه دوربین لازم است."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()
        faceLandmarker = FaceLandmarkerHelper(this, this)

        binding.snapshotButton.setOnClickListener { toggleSnapshot() }
        binding.gazeButton.setOnClickListener { toggleGazeTracking() }
        setDirection(GazeDirection.UNKNOWN)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val selector = CameraSelector.DEFAULT_FRONT_CAMERA

            val preview = Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setTargetRotation(binding.previewView.display.rotation)
                .build().also {
                    it.setSurfaceProvider(binding.previewView.surfaceProvider)
                }

            val analysis = ImageAnalysis.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_4_3)
                .setTargetRotation(binding.previewView.display.rotation)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                faceLandmarker.detect(imageProxy, mirrorFrontCamera = true)
            }

            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, selector, preview, analysis)
                binding.statusText.text = "دوربین آماده است — صورت را روبه‌روی دوربین نگه دارید."
            } catch (t: Throwable) {
                binding.statusText.text = "راه‌اندازی دوربین ناموفق بود."
                Toast.makeText(this, t.message ?: "Camera error", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleSnapshot() {
        if (!snapshotMode) {
            val bitmap = binding.previewView.bitmap
            if (bitmap == null) {
                Toast.makeText(this, "هنوز تصویر دوربین آماده نشده است.", Toast.LENGTH_SHORT).show()
                return
            }
            snapshotMode = true
            binding.faceOverlay.frozen = true
            binding.faceOverlay.setLabelsVisible(true)
            binding.snapshotView.setImageBitmap(bitmap)
            binding.snapshotView.visibility = View.VISIBLE
            binding.snapshotButton.text = "بازگشت به دوربین"
            binding.statusText.text = "عکس فریز شد؛ نقاط و برچسب‌های صورت روی آن نمایش داده می‌شوند."
        } else {
            leaveSnapshotMode()
        }
    }

    private fun leaveSnapshotMode() {
        snapshotMode = false
        binding.faceOverlay.frozen = false
        binding.snapshotView.setImageDrawable(null)
        binding.snapshotView.visibility = View.GONE
        binding.snapshotButton.text = "عکس + برچسب صورت"
        binding.statusText.text = if (gazeTracking) "ردیابی جهت نگاه فعال است." else "نمای زنده فعال است."
    }

    private fun toggleGazeTracking() {
        if (snapshotMode) leaveSnapshotMode()
        gazeTracking = !gazeTracking
        gazeEstimator.reset()
        binding.gazeButton.text = if (gazeTracking) "توقف ردیابی چشم" else "شروع ردیابی چشم"
        binding.hintText.text = if (gazeTracking) {
            "فعال: چشم‌ها را بالا، پایین، چپ و راست حرکت دهید."
        } else {
            "برای ردیابی نگاه، صورت را روبه‌روی دوربین نگه دارید."
        }
        if (!gazeTracking) setDirection(GazeDirection.UNKNOWN)
    }

    override fun onResult(result: FaceLandmarkerResult, imageWidth: Int, imageHeight: Int) {
        runOnUiThread {
            val face = result.faceLandmarks().firstOrNull()
            if (face == null) {
                if (!snapshotMode) binding.statusText.text = "صورتی پیدا نشد."
                setDirection(GazeDirection.UNKNOWN)
                return@runOnUiThread
            }

            binding.faceOverlay.setResult(result, imageWidth, imageHeight)
            if (gazeTracking) {
                val gaze = gazeEstimator.estimate(face)
                setDirection(gaze.direction)
                binding.statusText.text = when (gaze.direction) {
                    GazeDirection.LEFT -> "جهت نگاه: چپ"
                    GazeDirection.RIGHT -> "جهت نگاه: راست"
                    GazeDirection.UP -> "جهت نگاه: بالا"
                    GazeDirection.DOWN -> "جهت نگاه: پایین"
                    GazeDirection.CENTER -> "جهت نگاه: مرکز"
                    GazeDirection.UNKNOWN -> "در حال تشخیص چشم…"
                }
            } else if (!snapshotMode) {
                binding.statusText.text = "صورت شناسایی شد."
            }
        }
    }

    override fun onError(message: String) {
        runOnUiThread {
            binding.statusText.text = "خطا: $message"
        }
    }

    private fun setDirection(direction: GazeDirection) {
        styleIndicator(binding.leftIndicator, direction == GazeDirection.LEFT)
        styleIndicator(binding.rightIndicator, direction == GazeDirection.RIGHT)
        styleIndicator(binding.upIndicator, direction == GazeDirection.UP)
        styleIndicator(binding.downIndicator, direction == GazeDirection.DOWN)
    }

    private fun styleIndicator(view: TextView, active: Boolean) {
        val drawable = if (active) R.drawable.direction_active else R.drawable.direction_idle
        view.background = ContextCompat.getDrawable(this, drawable)
        view.alpha = if (active) 1f else 0.72f
    }

    override fun onDestroy() {
        faceLandmarker.close()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
