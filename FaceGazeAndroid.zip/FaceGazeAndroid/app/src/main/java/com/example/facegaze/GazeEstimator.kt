package com.example.facegaze

import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

enum class GazeDirection { LEFT, RIGHT, UP, DOWN, CENTER, UNKNOWN }

data class GazeResult(
    val direction: GazeDirection,
    val horizontalRatio: Float,
    val verticalRatio: Float
)

/**
 * Lightweight gaze-direction estimator based on MediaPipe iris position inside each eye.
 * This is an approximation, not medical/diagnostic eye tracking.
 */
class GazeEstimator {
    private var filteredX = 0.5f
    private var filteredY = 0.5f
    private var initialized = false

    fun reset() {
        initialized = false
        filteredX = 0.5f
        filteredY = 0.5f
    }

    fun estimate(landmarks: List<NormalizedLandmark>): GazeResult {
        if (landmarks.size < 478) return GazeResult(GazeDirection.UNKNOWN, 0.5f, 0.5f)

        // MediaPipe Face Mesh iris indices: 468 and 473 are iris centers.
        val eyeA = eyeRatio(landmarks, 33, 133, 159, 145, 468)
        val eyeB = eyeRatio(landmarks, 362, 263, 386, 374, 473)
        val rawX = (eyeA.first + eyeB.first) / 2f
        val rawY = (eyeA.second + eyeB.second) / 2f

        if (!initialized) {
            filteredX = rawX
            filteredY = rawY
            initialized = true
        } else {
            val alpha = 0.35f
            filteredX = alpha * rawX + (1f - alpha) * filteredX
            filteredY = alpha * rawY + (1f - alpha) * filteredY
        }

        return estimateFromRatios(filteredX, filteredY)
    }

    private fun eyeRatio(
        lm: List<NormalizedLandmark>,
        corner1: Int,
        corner2: Int,
        upper: Int,
        lower: Int,
        iris: Int
    ): Pair<Float, Float> {
        val xMin = min(lm[corner1].x(), lm[corner2].x())
        val xMax = max(lm[corner1].x(), lm[corner2].x())
        val yMin = min(lm[upper].y(), lm[lower].y())
        val yMax = max(lm[upper].y(), lm[lower].y())

        val x = ((lm[iris].x() - xMin) / (xMax - xMin).coerceAtLeast(0.0001f)).coerceIn(0f, 1f)
        val y = ((lm[iris].y() - yMin) / (yMax - yMin).coerceAtLeast(0.0001f)).coerceIn(0f, 1f)
        return x to y
    }

    companion object {
        /** Kept pure so it can be unit-tested without an Android camera. */
        fun estimateFromRatios(x: Float, y: Float): GazeResult {
            val dx = x - 0.5f
            val dy = y - 0.5f
            val horizontalThreshold = 0.085f
            val verticalThreshold = 0.11f

            val hStrength = abs(dx) / horizontalThreshold
            val vStrength = abs(dy) / verticalThreshold

            val direction = when {
                hStrength < 1f && vStrength < 1f -> GazeDirection.CENTER
                hStrength >= vStrength && dx < 0f -> GazeDirection.LEFT
                hStrength >= vStrength && dx > 0f -> GazeDirection.RIGHT
                dy < 0f -> GazeDirection.UP
                else -> GazeDirection.DOWN
            }
            return GazeResult(direction, x, y)
        }
    }
}
