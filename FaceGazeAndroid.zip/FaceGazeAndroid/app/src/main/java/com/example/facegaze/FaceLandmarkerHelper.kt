package com.example.facegaze

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageProxy
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult

class FaceLandmarkerHelper(
    context: Context,
    private val listener: Listener
) {
    private val landmarker: FaceLandmarker

    init {
        val baseOptions = BaseOptions.builder()
            .setDelegate(Delegate.CPU)
            .setModelAssetPath(MODEL_NAME)
            .build()

        val options = FaceLandmarker.FaceLandmarkerOptions.builder()
            .setBaseOptions(baseOptions)
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumFaces(1)
            .setMinFaceDetectionConfidence(0.5f)
            .setMinFacePresenceConfidence(0.5f)
            .setMinTrackingConfidence(0.5f)
            .setOutputFaceBlendshapes(false)
            .setResultListener(::onResult)
            .setErrorListener { listener.onError(it.message ?: "MediaPipe error") }
            .build()

        landmarker = FaceLandmarker.createFromOptions(context, options)
    }

    fun detect(imageProxy: ImageProxy, mirrorFrontCamera: Boolean = true) {
        val frameTime = SystemClock.uptimeMillis()
        try {
            val bitmapBuffer = Bitmap.createBitmap(
                imageProxy.width,
                imageProxy.height,
                Bitmap.Config.ARGB_8888
            )
            val buffer = imageProxy.planes[0].buffer
            buffer.rewind()
            bitmapBuffer.copyPixelsFromBuffer(buffer)

            val matrix = Matrix().apply {
                postRotate(imageProxy.imageInfo.rotationDegrees.toFloat())
                if (mirrorFrontCamera) {
                    postScale(-1f, 1f, imageProxy.width.toFloat(), imageProxy.height.toFloat())
                }
            }
            val rotated = Bitmap.createBitmap(
                bitmapBuffer,
                0,
                0,
                bitmapBuffer.width,
                bitmapBuffer.height,
                matrix,
                true
            )
            val mpImage = BitmapImageBuilder(rotated).build()
            landmarker.detectAsync(mpImage, frameTime)
        } catch (t: Throwable) {
            listener.onError(t.message ?: "Frame conversion failed")
        } finally {
            imageProxy.close()
        }
    }

    private fun onResult(result: FaceLandmarkerResult, input: MPImage) {
        listener.onResult(result, input.width, input.height)
    }

    fun close() = landmarker.close()

    interface Listener {
        fun onResult(result: FaceLandmarkerResult, imageWidth: Int, imageHeight: Int)
        fun onError(message: String)
    }

    companion object {
        private const val MODEL_NAME = "face_landmarker.task"
    }
}
