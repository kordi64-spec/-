package com.example.facegaze

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import kotlin.math.max

class FaceOverlayView(context: Context, attrs: AttributeSet?) : View(context, attrs) {
    private var result: FaceLandmarkerResult? = null
    private var imageWidth = 1
    private var imageHeight = 1
    private var showLabels = true
    var frozen: Boolean = false

    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 90, 220, 255)
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }
    private val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(66, 211, 146)
        strokeWidth = 5f
        style = Paint.Style.STROKE
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 34f
        style = Paint.Style.FILL
        setShadowLayer(5f, 1f, 1f, Color.BLACK)
    }
    private val arrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(255, 214, 77)
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }

    fun setResult(newResult: FaceLandmarkerResult, inputWidth: Int, inputHeight: Int) {
        if (frozen) return
        result = newResult
        imageWidth = inputWidth
        imageHeight = inputHeight
        invalidate()
    }

    fun setLabelsVisible(value: Boolean) {
        showLabels = value
        invalidate()
    }

    fun clear() {
        result = null
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val face = result?.faceLandmarks()?.firstOrNull() ?: return
        if (face.isEmpty()) return

        // PreviewView uses center-crop/FILL_CENTER; mimic the same mapping.
        val scale = max(width / imageWidth.toFloat(), height / imageHeight.toFloat())
        val scaledW = imageWidth * scale
        val scaledH = imageHeight * scale
        val offsetX = (width - scaledW) / 2f
        val offsetY = (height - scaledH) / 2f

        fun px(l: NormalizedLandmark) = l.x() * imageWidth * scale + offsetX
        fun py(l: NormalizedLandmark) = l.y() * imageHeight * scale + offsetY

        // Draw the complete facial landmark cloud lightly.
        face.forEach { canvas.drawCircle(px(it), py(it), 1.5f, pointPaint) }

        drawLoop(canvas, face, RIGHT_EYE, ::px, ::py)
        drawLoop(canvas, face, LEFT_EYE, ::px, ::py)
        drawOpen(canvas, face, RIGHT_BROW, ::px, ::py)
        drawOpen(canvas, face, LEFT_BROW, ::px, ::py)
        drawLoop(canvas, face, LIPS, ::px, ::py)
        drawLoop(canvas, face, FACE_OVAL, ::px, ::py)
        drawLoop(canvas, face, RIGHT_IRIS, ::px, ::py)
        drawLoop(canvas, face, LEFT_IRIS, ::px, ::py)

        if (showLabels) {
            label(canvas, face, 10, "پیشانی", -150f, -55f, ::px, ::py)
            label(canvas, face, 70, "ابروی راست", -200f, -15f, ::px, ::py)
            label(canvas, face, 300, "ابروی چپ", 40f, -15f, ::px, ::py)
            label(canvas, face, 159, "پلک / مژه", -220f, 10f, ::px, ::py)
            label(canvas, face, 386, "پلک / مژه", 35f, 10f, ::px, ::py)
            label(canvas, face, 468, "چشم راست", -205f, 70f, ::px, ::py)
            label(canvas, face, 473, "چشم چپ", 45f, 70f, ::px, ::py)
            label(canvas, face, 1, "بینی", 60f, 10f, ::px, ::py)
            label(canvas, face, 13, "لب", 75f, 35f, ::px, ::py)
        }
    }

    private fun drawLoop(
        canvas: Canvas,
        face: List<NormalizedLandmark>,
        indices: IntArray,
        px: (NormalizedLandmark) -> Float,
        py: (NormalizedLandmark) -> Float
    ) {
        if (indices.any { it >= face.size }) return
        val path = Path()
        path.moveTo(px(face[indices[0]]), py(face[indices[0]]))
        for (i in 1 until indices.size) path.lineTo(px(face[indices[i]]), py(face[indices[i]]))
        path.close()
        canvas.drawPath(path, accentPaint)
    }

    private fun drawOpen(
        canvas: Canvas,
        face: List<NormalizedLandmark>,
        indices: IntArray,
        px: (NormalizedLandmark) -> Float,
        py: (NormalizedLandmark) -> Float
    ) {
        if (indices.any { it >= face.size }) return
        val path = Path()
        path.moveTo(px(face[indices[0]]), py(face[indices[0]]))
        for (i in 1 until indices.size) path.lineTo(px(face[indices[i]]), py(face[indices[i]]))
        canvas.drawPath(path, accentPaint)
    }

    private fun label(
        canvas: Canvas,
        face: List<NormalizedLandmark>,
        index: Int,
        text: String,
        dx: Float,
        dy: Float,
        px: (NormalizedLandmark) -> Float,
        py: (NormalizedLandmark) -> Float
    ) {
        if (index >= face.size) return
        val x = px(face[index])
        val y = py(face[index])
        val tx = x + dx
        val ty = y + dy
        canvas.drawLine(x, y, tx, ty, arrowPaint)
        canvas.drawCircle(x, y, 7f, arrowPaint)
        canvas.drawText(text, tx, ty, labelPaint)
    }

    companion object {
        private val RIGHT_EYE = intArrayOf(33, 160, 158, 133, 153, 144)
        private val LEFT_EYE = intArrayOf(362, 385, 387, 263, 373, 380)
        private val RIGHT_BROW = intArrayOf(46, 53, 52, 65, 55)
        private val LEFT_BROW = intArrayOf(276, 283, 282, 295, 285)
        private val LIPS = intArrayOf(61, 40, 37, 0, 267, 270, 291, 321, 314, 17, 84, 91)
        private val FACE_OVAL = intArrayOf(10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 288, 397, 365, 379, 378, 400, 377, 152, 148, 176, 149, 150, 136, 172, 58, 132, 93, 234, 127, 162, 21, 54, 103, 67, 109)
        private val RIGHT_IRIS = intArrayOf(469, 470, 471, 472)
        private val LEFT_IRIS = intArrayOf(474, 475, 476, 477)
    }
}
