# Face Gaze Android Demo

Native Android prototype (Kotlin + CameraX + MediaPipe Face Landmarker).

## Features
- Front-camera preview.
- On-device face landmarks.
- Snapshot/freeze button with labeled forehead, eyebrows, eyes, eyelid/lash region, nose and lips.
- Live approximate gaze direction: left/right/up/down/center.
- Four direction indicators highlight as gaze changes.
- No image is uploaded to a server by this prototype.

## Build
1. Open this directory in Android Studio, or push it to GitHub Codespaces.
2. Use JDK 17.
3. Run `./gradlew assembleDebug` (or use Android Studio Build > Build APK).
4. Install `app/build/outputs/apk/debug/app-debug.apk` on a physical Android device (API 24+).

The Face Landmarker model is stored in `app/src/main/assets/face_landmarker.task`.

## Notes
Gaze direction is estimated from iris position inside the eyelids and is not a precision/medical eye tracker. Thresholds in `GazeEstimator.kt` may need per-device/user calibration.
